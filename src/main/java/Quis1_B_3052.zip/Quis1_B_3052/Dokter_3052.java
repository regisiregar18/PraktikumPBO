package Quis1_B_3052;

public class Dokter_3052 extends Penduduk_3052 {
    int jmlPasien;
    int jmlObat;
    
    private double totalPendapatanDokter(){
        System.out.println("Total Pendatapatan : " + ((jmlPasien*50000) + (jmlObat*10000)));
        return 0;
    }
    
    public void tampilDataDokter(){
        System.out.println("===DATA DOKTER===");
        
    }
}
