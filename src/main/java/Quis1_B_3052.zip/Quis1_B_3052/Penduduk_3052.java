package Quis1_B_3052;

public class Penduduk_3052 {

    String nik_3052;
    String nama_3052;
    int umur_3052;
    String alamat_3052;

    public void tampilDataPenduduk() {
        System.out.println("NIK : " + nik_3052);
        System.out.println("Nama : " + nama_3052);
        System.out.println("Umur : " + umur_3052);
        System.out.println("Alamat : " + alamat_3052);
        extraInfo();
    }

    public void extraInfo() {
    }
}
