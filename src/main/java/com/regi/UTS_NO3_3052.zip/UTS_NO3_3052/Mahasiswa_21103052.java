package com.regi.UTS_NO3_3052;

public class Mahasiswa_21103052 {
    protected String nim;
    protected String nama;
    protected String jurusan;
    protected int ipk;
    
    public void tampilDataMhs(){
        
    }
}
