package com.regi.UTS_NO3_3052;

public interface IPendapatan_21103052 {
     public double totalPendapatan();
}
